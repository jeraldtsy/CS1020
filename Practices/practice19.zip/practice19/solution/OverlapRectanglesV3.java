// This program reads in a number of rectangles and compute the
// overlap of all rectangles.
// This program uses the MyRect class.
// Author: Aaron Tan

import java.util.*;
import java.awt.*;

public class OverlapRectanglesV3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		MyRect rect1, rect2;

		System.out.print("How many rectangles? ");
		int numRect = sc.nextInt();

		System.out.print("Enter 2 opposite vertices of first rectangle: ");
		rect1 = readRectangle(sc);
		arrangeVertices(rect1);
   		// System.out.println("First rectangle: " + rect1);

		for (int i=2; i<=numRect; i++) {
			System.out.print("Enter 2 opposite vertices of next rectangle: ");
			rect2 = readRectangle(sc);
			arrangeVertices(rect2);
   			// System.out.println("Next rectangle: " + rect2);
			rect1 = overlap(rect1, rect2);
			// System.out.println("Overlap rectangle: " + rect1);
		}

		int overlapArea = area(rect1);
		if (overlapArea == 0)
			System.out.println("No overlap");
		else {
			System.out.println("Overlap rectangle: " + rect1);
			System.out.println("Overlap area = " + overlapArea);
		}
	}

	// Read data of a rectangle, create a rectangle object
	// and return it.
	public static MyRect readRectangle(Scanner sc) {
		Point vertex1 = new Point(sc.nextInt(), sc.nextInt());
		Point vertex2 = new Point(sc.nextInt(), sc.nextInt());
		return new MyRect(vertex1, vertex2);
	}

	// To rearrange the 2 opposite vertices of rect
	// such that the first vertex v1 becomes the bottom-left vertex
	// and the second vertex v2 becomes the top-right vertex.
	public static void arrangeVertices(MyRect rect) {
		int lowerX = Math.min(rect.getVertex1().x, rect.getVertex2().x);
		int upperX = Math.max(rect.getVertex1().x, rect.getVertex2().x);
		int lowerY = Math.min(rect.getVertex1().y, rect.getVertex2().y);
		int upperY = Math.max(rect.getVertex1().y, rect.getVertex2().y);

		rect.getVertex1().setLocation(lowerX, lowerY);
		rect.getVertex2().setLocation(upperX, upperY);
	}

	// To compute the overlap rectangle of rect1 and rect2
	public static MyRect overlap(MyRect rect1, MyRect rect2) {
		// If the 2 rectangles overlap, the overlap area
		// is also a rectangle, let's call it ov. Let the 
		// bottom-left vertex of ov be at point (botLeftX, botLeftY)
		// and its top-right vertex be at point (topRightX, topRightY).

		int botLeftX = Math.max(rect1.getVertex1().x, rect2.getVertex1().x);
		int topRightX = Math.min(rect1.getVertex2().x, rect2.getVertex2().x);
		int botLeftY = Math.max(rect1.getVertex1().y, rect2.getVertex1().y);
		int topRightY = Math.min(rect1.getVertex2().y, rect2.getVertex2().y);

		// Check degenerate case where there is no overlap
		if (botLeftX > topRightX || botLeftY > topRightY)
			return new MyRect(0, 0, 0, 0); // Create an "empty" rectangle
		else
			return new MyRect(botLeftX, botLeftY, topRightX, topRightY);
	}

	// To compute the area of rect
	public static int area(MyRect rect) {
		return (rect.getVertex2().x - rect.getVertex1().x) *
		       (rect.getVertex2().y - rect.getVertex1().y); 
	}

}

