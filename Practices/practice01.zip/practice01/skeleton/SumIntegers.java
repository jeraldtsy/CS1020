// This program computes sum of positive integers up to n
// Add import statement below
import ...

// Java naming convention:
// Class names should be in UpperCamelCase, with the first 
// letter of every word capitalised.
public class SumIntegers {

	public static void main(String[] args) {
		// Fill in the code for the main() method
		
	}

}
