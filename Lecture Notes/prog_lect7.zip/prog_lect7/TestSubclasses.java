public class TestSubclasses {

	public static void main(String[] args) {

		ClassA objA = new ClassA(123);
		ClassB objB = new ClassB(456);
		ClassC objC = new ClassC(789);

		objA.print();
		System.out.println("---------");
		objB.print();
		System.out.println("---------");
		objC.print();
	}
} 

