// This program reads the length of a side of a square and
// computes the area of the circle that encloses the square.

// Add import statement(s) below
import ...

public class CircleArea {

	// You are to write a circleArea(double r) method to 
	// return the area of a circle of radius r.

	public static void main(String[] args) {
		// Fill in the code below


	}
}

