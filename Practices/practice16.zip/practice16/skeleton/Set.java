// Define the Set class

import java.util.ArrayList;

class Set {

	private ArrayList<Integer> members;

	// Constructors


	// toString() method
	public String toString() {

	}

	// Return true if 'this' is a subset of 'set', 
	// otherwise return false.
	public boolean isSubset(Set set) {

		return true; // this is a stub
	}
}

