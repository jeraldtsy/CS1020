import java.util.*;

class Knob {

	// Data attributes
	boolean isOn;      // is the device on?
	String currPos;    // current position of knob
	String targetPos;  // target position of knob

	// Constructor
	public Knob(boolean state, String newCurrPos, String newTargetPos) { 
		// fill in the code
	}

	// Determine whether the device is on or off after num moves
	public boolean deviceIsOn(int num) {
		// fill in the code

		return false; // this is a stub
	}

	// Compute the least number of moves to turn the knob
	public int numOfMoves() {                       

		return 123; // this is a stub
	}
}

