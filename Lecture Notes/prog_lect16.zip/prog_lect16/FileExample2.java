import java.util.*;
import java.io.*;

public class FileExample2 {

	public static void main(String[] args) 
		                     throws FileNotFoundException {

		try {
			Scanner infile = new Scanner(new File("example"));
			int sum = 0;
			while (infile.hasNextInt()) {
				sum += infile.nextInt();
			}
			System.out.println("Sum = " + sum);
		}
		catch (FileNotFoundException e) {
			System.out.println("File 'example' not found!");
		}

	}
}
