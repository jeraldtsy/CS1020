// MissingDigitsV2.java
// To find digits that do not appear in user's input number.
// This version uses the Vector class.
import java.util.*;

public class MissingDigitsV2 {

	public static void main(String[] args) {

	}
}

