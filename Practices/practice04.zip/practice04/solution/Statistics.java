// This program computes the mean and standard deviation
// of an array of values.
import java.util.*;
import java.text.*;

public class Statistics {

	public static void main(String[] args) {
		DecimalFormat df = new DecimalFormat("0.000");

		int[] arr = readArray();

		// For checking
		// System.out.print("Values: ");
		// printArray(arr);

		System.out.println("Mean = " + df.format(computeMean(arr)));
		System.out.println("Standard deviation = " 
		                    + df.format(computeStdDev(arr)));
	}

	// Read a list of values into an array arr
	public static int[] readArray() {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter size of array: ");
		int size = sc.nextInt();
		int[] arr = new int[size];

		System.out.print("Enter " + size);
		if (size == 1)
			System.out.println(" value: ");
		else
			System.out.println(" values: ");

		for (int i=0; i<size; i++) {
			arr[i] = sc.nextInt();
		}

		return arr;
	}

	// Compute mean of the values in arr
	// Precond: arr.length > 0
	public static double computeMean(int[] arr) {
		double sum = 0.0;

		for (int element: arr) {
			sum += element;
		}
		return sum/arr.length;
	}

	// Compute standard deviation of the values in arr
	// Precond: arr.length > 0
	public static double computeStdDev(int[] arr) {
		double sumSqDiff = 0.0; // sum of square of difference
		double mean = computeMean(arr);

		for (int element: arr) {
			sumSqDiff += Math.pow(element - mean, 2);
		}
		return Math.sqrt(sumSqDiff/arr.length);
	}

	// Print the array arr on a single line.
	// Note that the last element has a space after it.
	public static void printArray(int[] arr) {
		for (int element: arr) {
			System.out.print(element + " ");
		}
		System.out.println();
	}
} 

