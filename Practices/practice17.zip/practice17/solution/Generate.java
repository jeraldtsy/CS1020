// To generate random x- and y-coordinates.
// Aaron Tan

import java.util.*;

public class Generate {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Random rand = new Random();

		int size = sc.nextInt();
		System.out.println(size);

		int limit = sc.nextInt();

		for (int i=0; i<size; i++) {
			System.out.println((rand.nextInt(limit) - limit/2) + " " +
			                   (rand.nextInt(limit) - limit/2));
		}
	}
}

