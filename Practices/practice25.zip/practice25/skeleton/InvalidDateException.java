// InvalidDateException class.
// Fill in the parts that are marked "WRITE YOUR CODE HERE."

public class InvalidDateException 
    
    // =======================
    // WRITE YOUR CODE HERE.
    // =======================
   
    
    /************** Constructors **********************/ 
    
    public InvalidDateException(String s) {
        // =======================
        // WRITE YOUR CODE HERE.
        // =======================
    }

}
