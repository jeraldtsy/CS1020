import java.util.*;

/******* Class definition for ListNode *******/
class ListNode <E> {
	/* data attributes */
	private E element;
	private ListNode <E> next;

	/* constructors */
	public ListNode(E element) { 
		this(element, null); 
	}

	public ListNode(E element, ListNode <E> next) { 
		this.element = element; 
		this.next = next; 
	}

	public ListNode <E> getNext() {
		return this.next;
	}

	public E getElement() {
		return this.element;
	}

	public void setNext(ListNode <E> next) {
		this.next = next;
	}
}
/******* Class definition for MySortedLinkedList *******/
class MySortedLinkedList <E extends Comparable <E>> {

	// Data attributes
	private ListNode <E> head = null;
	private int numNodes = 0;

	// Return true if list is empty; otherwise return false.
	public boolean isEmpty() { 
		return (numNodes == 0);  // or return (head == null);
	}

	// Return number of nodes in list.
	public int size() { 
		return numNodes; 
	}

	// Return value in the first node.
	public E getFirst() throws NoSuchElementException {
		if (head == null) 
			throw new NoSuchElementException("List is empty!");
		else 
			return head.getElement();
	}

	// Return true if list contains item, otherwise return false.
	public boolean contains(E item) {
		for (ListNode <E> curr = head; curr != null; curr = curr.getNext())
			if (curr.getElement().equals(item)) 
				return true;

		return false;
	}

	// Add item to front of list.
	public void addFirst(E item) {
		head = new ListNode <E> (item, head);
		numNodes++;
	}

	// Remove first node of list.
	public E removeFirst() throws NoSuchElementException {
		if (head == null) 
			throw new NoSuchElementException("Can't remove from an empty list!");
		else { 
			ListNode <E> first = head;
			head = head.getNext();
			numNodes--;
			return first.getElement();
		}
	}

	// Return string representation of list.
	public String toString() {
		ListNode <E> curr = head;
		String str = "[";

		if (curr != null) {
			str += curr.getElement();
			curr = curr.getNext();
			while (curr != null) {
				str += ", " + curr.getElement();
				curr = curr.getNext();
			}
		}
		str += "]";
		return str;
	}

	// Add item to the list, maintaining the order.
	public void addOrdered(E item) {

		// Check if list is empty or item is smaller than first element.
		// If so, add node in front
		ListNode <E> newNode = new ListNode <E> (item, null);
		if ((head == null) || (item.compareTo(head.getElement()) < 0)) {
			head = new ListNode <E> (item, head);
		}
		else {
			ListNode <E> curr = head.getNext();
			ListNode <E> prev = head;
			while ((curr != null) && (item.compareTo(curr.getElement()) > 0)) {
				prev = curr;
				curr = curr.getNext();
			}
			// insert between prev and curr
			newNode.setNext(curr);
			prev.setNext(newNode);
		}
		numNodes++;
	}

}

