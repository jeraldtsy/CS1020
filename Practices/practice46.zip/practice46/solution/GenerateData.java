// This program generate a list of random integers and strings
import java.util.*;

public class GenerateData {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Random rnd = new Random();

		int n = Integer.parseInt(args[0]); // number of values to be generated
		int upper = Integer.parseInt(args[1]); // upper limit of values

		// Output n and the list of random integers and strings generated.
	    // Random integers generated have value in the range [0, upper].
		// Strings generated comprise 1 to 30 upper-case letters.
		System.out.println(n);
		int length; // length of string
		String data;
		for (int i=0; i<n; i++) {
			System.out.print(rnd.nextInt(upper+1) + " ");
			length = rnd.nextInt(30) + 1; // length = [1,30]
			data = "";
			for (int j=0; j<length; j++) {
				data += (char) (rnd.nextInt(26) + (int)'A'); 
			}
			System.out.println(data);
		}
	}
}

