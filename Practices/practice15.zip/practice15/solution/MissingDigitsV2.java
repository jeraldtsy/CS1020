// MissingDigitsV2.java
// To find digits that do not appear in user's input number.
// This version uses the Vector class.
import java.util.*;

public class MissingDigitsV2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Vector<Boolean> found = new Vector<Boolean>();

		// Add 10 elements, all set to false
		for (int i=0; i<10;i++) {
			found.add(false);
		}

		System.out.print("Enter a number: ");
		int number = sc.nextInt();
		System.out.print("Missing digits in " + number + ": ");

		while (number > 0) {
			found.set(number%10, true);
			number /= 10;
		}

		for (int i=0; i<10; i++) {
			if (!found.get(i))
				System.out.print(i + " ");
		}
		System.out.println();
	}
}

