import java.util.*;
import java.io.*;

public class InputTokens {

	public static void main(String[] args) 
		                     throws FileNotFoundException {

		Scanner infile = new Scanner(new File("tokens"));

		int a = infile.nextInt();
		String b = infile.next();
		String c = infile.nextLine();
		double d = infile.nextDouble();

		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("c = " + c);
		System.out.println("d = " + d);
	}
}
