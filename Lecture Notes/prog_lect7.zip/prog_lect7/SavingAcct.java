class SavingAcct extends BankAcct {

	protected double rate;    // interest 

	public SavingAcct(int aNum, double bal, double rate) {
		super(aNum, bal);
		this.rate = rate;
	}

	public double getRate() {
		return rate;
	}

	public void payInterest() {   
		balance += balance * rate;
	}

	public void print() {
		System.out.println("Account number: " + getAcctNum());
		System.out.printf("Balance: $%.2f\n", getBalance());
		System.out.printf("Interest: %.2f%%\n", getRate());
	}

}

