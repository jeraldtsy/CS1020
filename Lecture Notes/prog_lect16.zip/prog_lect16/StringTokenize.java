import java.util.*;
import java.io.*;

public class StringTokenize {

	public static void main(String[] args) {

		String msg = "345 students in CS1020.";
		Scanner sc = new Scanner(msg);

		int a = sc.nextInt();
		String b = sc.next();
		String c = sc.nextLine();

		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("c = " + c);
	}
}
