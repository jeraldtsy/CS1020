// To compute the distance of the nearest pair of points
// among a list of points.
// Aaron Tan

import java.util.*;
import java.awt.*;

public class NearestPoints {

	// Return the distance between ptA and ptB
	public static double distance(Point ptA, Point ptB) {
		return Math.sqrt((ptA.x - ptB.x) * (ptA.x - ptB.x) + 
		                 (ptA.y - ptB.y) * (ptA.y - ptB.y));
	}

	// Compute the distance of the nearest pair of points
	public static double distClosestPair(ArrayList<Point> points) {
		// Examine every pair of points
		double minDist = distance(points.get(0), points.get(1));
		double dist;
		int size = points.size();

		for (int i=0; i<size-1; i++) {
			for (int j=i+1; j<size; j++) {
				dist = distance(points.get(i), points.get(j));
				// System.out.printf("dist = %.2f\n", dist); // for checking
				if (dist < minDist) 
					minDist = dist;
			}
		}
		return minDist;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x, y; // x- and y-coordinates of a point

		int size = sc.nextInt();  // size of list;

		ArrayList<Point> points = new ArrayList<Point>(size);

		// read data into points
		for (int i=0; i<size; i++) {
			x = sc.nextInt();
			y = sc.nextInt();
			points.add(new Point(x,y));
		}

		// System.out.println(points); // for checking

		double minDist = distClosestPair(points);
		System.out.printf("Minimum distance = %.2f\n", minDist);
	}
}

