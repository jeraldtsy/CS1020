// MissingDigits.java
// To find digits that do not appear in user's input number.
import java.util.*;

public class MissingDigits {

	public static void main(String[] args) {

	}
}

