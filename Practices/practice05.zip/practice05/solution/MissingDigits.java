// MissingDigits.java
// To find digits that do not appear in user's input number.
import java.util.*;

public class MissingDigits {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean[] found = new boolean[10];

		System.out.print("Enter a number: ");
		int number = sc.nextInt();
		System.out.print("Missing digits in " + number + ": ");

		while (number > 0) {
			found[number%10] = true;
			number /= 10;
		}

		for (int i=0; i<10; i++) {
			if (!found[i])
				System.out.print(i + " ");
		}
		System.out.println();
	}
}

