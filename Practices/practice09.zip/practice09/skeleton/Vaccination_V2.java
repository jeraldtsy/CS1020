// Testing the Scanner class.
// This program reads the name, age and vaccination status of
// some children and computes their average age and percentage
// of children who are vaccinated.
// Unlike the earlier version (practice exercise 4), this version
// keeps reading in data until there is no more name.

// Add import statement(s) below
import ...

public class Vaccination_V2 {

	public static void main(String[] args) {
		String name;
		int age, totalAge = 0;
		boolean vaccinated;
		int numVaccinated = 0; 
		int numOfChildren = 0;

		// Fill in the code below


	}
}

