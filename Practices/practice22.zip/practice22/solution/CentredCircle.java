// CentredCircle class:
//   Subclass of Circle
//   Instance attribute: centre
// Aaron Tan

import java.awt.geom.*;

class CentredCircle extends Circle {

	/************** Data members **********************/
	protected Point2D.Double centre;

	/************** Constructors **********************/
	// Default constructor creates a yellow circle 
	// with radius 10.0 circle and centre at (0,0)

	public CentredCircle() {
		super();
		setCentre(new Point2D.Double(0, 0));
	}

	public CentredCircle(String colour, double radius, Point2D.Double centre) {
		super(colour, radius);
		setCentre(centre);
	}

	/**************** Accessor ***********************/
	public Point2D.Double getCentre() {
		return this.centre;   // 'this' is optional here
	}

	/**************** Mutator ************************/
	public void setCentre(Point2D.Double centre) {
		this.centre = centre;  // 'this' is required here
	}

	/***************** Overriding methods ******************/
	// Overriding toString() method
	public String toString() {
		return "[" + getColour() + ", " + getRadius() + ", "
		       + "(" + getCentre().getX() + "," 
		       + getCentre().getY() + ")]";
	}

	// Overriding equals() method
	public boolean equals(Object obj) {
		if (obj instanceof CentredCircle) {
			CentredCircle circle = (CentredCircle) obj;
			return super.equals(circle) &&
			       this.getCentre().equals(circle.getCentre());
		}
		else
			return false;
	}
}

