// This program reads data in different formats and performs
// the respective operations.
import java.util.*;

public class Reading {

	// Perform operation on the operands based on the string in op
	public static int operate(String op, int operand1, int operand2) {
		if (op.equals("ADD"))
			return operand1 + operand2;
		else if (op.equals("SUB"))
			return operand1 - operand2;
		else if (op.equals("MUL"))
			return operand1 * operand2;
		else
			return 0;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		String op;
		String typeOfInput = sc.next();
		int operand1, operand2;

		if (typeOfInput.equals("LIMIT")) {
			int limit = sc.nextInt();
			for (int i=0; i<limit; i++) {
				op = sc.next();
				operand1 = sc.nextInt();
				operand2 = sc.nextInt();
				System.out.println(operate(op, operand1, operand2));
			}
		}
		else if (typeOfInput.equals("SENTINEL")) {
			op = sc.next();
			while (!op.equals("-1")) {
				operand1 = sc.nextInt();
				operand2 = sc.nextInt();
				System.out.println(operate(op, operand1, operand2));
				op = sc.next();
			}
		}

		else if (typeOfInput.equals("EOF")) {
			while (sc.hasNext()) {
				op = sc.next();
				operand1 = sc.nextInt();
				operand2 = sc.nextInt();
				System.out.println(operate(op, operand1, operand2));
			}
		}
	}
}
