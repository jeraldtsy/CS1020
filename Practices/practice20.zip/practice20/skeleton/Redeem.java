// This program reads in an item's cost and some coupons' information,
// and then determines which is the best coupon to use and the amount 
// to pay.

// Add import statement(s) below


public class Redeem {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);


		// Output the result
		// Ensure your output is in the right format
		System.out.println("Best choice: ");
		System.out.printf("You need to pay $%.2f\n");
	}
}

