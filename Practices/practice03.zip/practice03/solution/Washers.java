// Compute total weight of a batch of washers
import java.util.*;

public class Washers {

	// Compute area of a circle 
	public static double circleArea(double diameter) {
		return Math.pow(diameter/2, 2) * Math.PI;
	}

	public static void main(String[] args) {
		double d1,   // d1 = hole circle's diameter
			   d2,   // d2 = big circle's diameter
			   thickness, density;
		int    qty;
		double unitWeight,    // single washer's weight
			   totalWeight,   // total weight of a batch of washers
			   rimArea;       // single washer's rim area 

		Scanner sc = new Scanner(System.in);

		System.out.print("Inner diameter in cm: ");
		d1 = sc.nextDouble();
		System.out.print("Outer diameter in cm: ");
		d2 = sc.nextDouble();
		System.out.print("Thickness in cm: ");
		thickness = sc.nextDouble();
		System.out.print("Density in grams per cubic cm: ");
		density = sc.nextDouble();
		System.out.print("Quantity: ");
		qty = sc.nextInt();

		// compute weight of a single washer
		rimArea = circleArea(d2) - circleArea(d1);
		unitWeight = rimArea * thickness * density;

		// compute weight of a batch of washers
		totalWeight = unitWeight * qty;

		System.out.printf("Total weight of %d washers is %.2f grams.\n", 
		                  qty, totalWeight);
	}
}

