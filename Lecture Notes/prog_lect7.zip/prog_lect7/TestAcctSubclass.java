public class TestAcctSubclass {

	public static void transfer(BankAcct fromAcct, 
	                            BankAcct toAcct, double amt) {
		fromAcct.withdraw(amt);
		toAcct.deposit(amt);
	}

	public static void main(String[] args) {

		BankAcct ba = new BankAcct(1, 234.56);
		SavingAcct sa = new SavingAcct(2, 1000.0, 0.03);

		transfer(ba, sa, 123.45);

		ba.print();
		sa.print();
	}
} 

