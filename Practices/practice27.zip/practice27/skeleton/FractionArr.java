// Fraction class, using a 2-element integer array as data members

class FractionArr implements FractionI {

	/************** Data members **********************/
	private int[] members;

	/************** Constructors **********************/
	// Default constructor creates a fraction 1/1


	/**************** Accessors ***********************/



	/**************** Mutators ************************/



	/***************** Other methods ******************/



}

