// This program reads in an item's cost and some coupons' information,
// and then determines which is the best coupon to use and the amount 
// to pay.

import java.util.*;

public class Redeem {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		double price = sc.nextDouble();
		int num = sc.nextInt();

		Coupon bestCoupon = new Coupon(sc.next(), sc.nextDouble());
		double bestPayment = bestCoupon.payment(price);

		for (int i = 1; i < num; i++) {
			Coupon coupon = new Coupon(sc.next(), sc.nextDouble());
			double couponPayment = coupon.payment(price);

			if (bestPayment > 0) {
				if (couponPayment < bestPayment) {
					bestCoupon = coupon;
					bestPayment = couponPayment;
				}
			}
			else { // bestPayment <= 0
				if ((couponPayment <= 0) && (couponPayment > bestPayment)) {
					bestCoupon = coupon;
					bestPayment = couponPayment;
				}
			}
		}

		// Output the result
		// Ensure your output is in the right format
		System.out.println("Best choice: " + bestCoupon.getName());
		System.out.printf("You need to pay $%.2f\n", Math.max(0, bestPayment));
	}
}

