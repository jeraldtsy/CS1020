// CentredCircle class:
//   Subclass of Circle
//   Instance attribute: centre

// Add import statement(s) below


class CentredCircle {

	/************** Data members **********************/
	protected Point2D.Double centre;

	/************** Constructors **********************/
	// Default constructor creates a yellow circle 
	// with radius 10.0 circle and centre at (0,0)

	public CentredCircle() {
		// Fill in the code

	}

	public CentredCircle(String colour, double radius, Point2D.Double centre) {
		// Fill in the code

	}

	/**************** Accessor ***********************/
	public Point2D.Double getCentre() {
		// Fill in the code

	}

	/**************** Mutator ************************/
	public void setCentre(Point2D.Double centre) {
		// Fill in the code

	}

	/***************** Overriding methods ******************/
	// Overriding toString() method
	public String toString() {
		// Fill in the code

	}

	// Overriding equals() method
	public boolean equals(Object obj) {
		// Fill in the code

	}
}

