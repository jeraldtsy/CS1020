class ClassA {

	protected int value;

	public ClassA() {   
		// By default, numeric attributes are initialised to 0
	}

	public ClassA(int val) {
		value = val;
	}

	public void print() {
		System.out.println("Class A: value = " + value);
	}
}

