// Fraction class, using 2 integers as the data members

class Fraction implements FractionI {

	/************** Data members **********************/
	private int numer;
	private int denom;

	/************** Constructors **********************/
	// Default constructor creates a fraction 1/1


	/**************** Accessors ***********************/



	/**************** Mutators ************************/



	/***************** Other methods ******************/



}

