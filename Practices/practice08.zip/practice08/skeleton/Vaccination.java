// Testing the Scanner class.
// This program reads the name, age and vaccination status of
// some children and computes their average age and percentage
// of children who are vaccinated.

// Add import statement(s) below
import ...

public class Vaccination {

	public static void main(String[] args) {
		String name;
		int age, totalAge = 0;
		boolean vaccinated;
		int numVaccinated = 0; 

		// Fill in the code below


	}
}

