// Fraction class

class Fraction {

	/************** Data members **********************/
	private int numer;
	private int denom;

	/************** Constructors **********************/


	/**************** Accessors ***********************/


	/**************** Mutators ************************/


	/***************** Other methods ******************/



}

