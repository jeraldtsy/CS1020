import java.util.*;
import java.io.*;

public class FileExample1 {

	public static void main(String[] args) 
		                     throws FileNotFoundException {

		Scanner infile = new Scanner(new File("example"));
		int sum = 0;
		while (infile.hasNextInt()) {
			sum += infile.nextInt();
		}

		System.out.println("Sum = " + sum);
	}
}
