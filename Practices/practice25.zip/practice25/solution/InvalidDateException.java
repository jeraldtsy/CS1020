// InvalidDateException class.
// Fill in the parts that are marked "WRITE YOUR CODE HERE."

public class InvalidDateException extends Exception {

    /************** Constructors **********************/ 
    
    public InvalidDateException(String s) {
        super(s);
    }
    
}
