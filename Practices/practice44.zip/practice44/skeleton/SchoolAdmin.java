import java.util.Scanner;

/**
 * CS1020 (AY2014/5 Semester 2)
 * Name:
 * Matric. No.:
 * Lab group:
 * Write the program description below.
 * It is mandatory to write program description at the top of every program.
 *
 */
public class SchoolAdmin {
	
	public void run() {
		Scanner sc = new Scanner(System.in);
		
	}
	
	public static void main(String[] args) {
		SchoolAdmin sa = new SchoolAdmin();
		sa.run();
	}
}

class Student {
	
	/**
	 * calculate student's CAP based on current modules he has enrolled into
	 */
	public void calcCAP() {
		
	}
	
	/**
	 * add a new module to the student's profile
	 */
	public void addModule(String moduleCode, String gradeLetter) {
		
	}
	
	/**
	 * find the correct module based on the input module code
	 */
	private Module findModule(String moduleCode) {
		
	}

}

class Module {
	
}