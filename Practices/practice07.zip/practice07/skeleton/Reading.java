// This program reads data in different formats and performs
// the respective operations.

// Add import statement(s) below

public class Reading {

	// Add a method operate(String, int, int) below
	// Perform operation on the operands based on the string in op
	public static int operate(String op, int operand1, int operand2) {
		if (op.equals("ADD"))
			return operand1 + operand2;

		// complete the code
	}

	public static void main(String[] args) {
		// Fill in the code


	}
}
