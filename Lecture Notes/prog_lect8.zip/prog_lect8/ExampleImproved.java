import java.util.Scanner;
import java.util.InputMismatchException;

public class ExampleImproved {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean isError;

		do {
			System.out.print("Enter an integer: ");
			try {
				int num = sc.nextInt();
				System.out.println("num = " + num);
				isError = false;
			}
			catch (InputMismatchException e) {
				System.out.print("Incorrect input: integer required. ");
				sc.nextLine(); // skip newline
				isError = true;
			}
		} while (isError);
	}
}

