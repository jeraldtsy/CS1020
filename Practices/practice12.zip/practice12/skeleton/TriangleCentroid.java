// This program reads integer coordinates of 3 points and creates
// 3 Point objects. It then computes the centroid of a triangle
// having these 3 points as its vertices.

// Add the import statement(s) below

public class TriangleCentroid {

	// Returns the centroid of a triangle with 
	// 3 vertices v1, v2 and v3
	public static Point2D.Double centroid(Point v1, Point v2, Point v3) {

	}

	public static void main(String[] args) {
		// Fill in the code 

		System.out.print("Enter 3 vertices: ");

		System.out.println("Centroid at " + centroid(v1, v2, v3));
	}
}

