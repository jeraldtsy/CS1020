import java.util.*;

public class Postfix {

	public static void main (String [] args) throws NoSuchElementException {
		String postfixExp = "";
		//StackLL <Character> stack = new StackLL<Character>  ();
		//StackLLE<Character>  stack = new StackLLE<Character>  ();
		Stack<Character> stack = new Stack<Character>  ();
		//StackArr<Character>  stack = new StackArr<Character>  ();

		//Scanner scanner = new Scanner("a-b");
		//Scanner scanner = new Scanner("a-b/c");
		//Scanner scanner = new Scanner("a+b+d/c");
		//Scanner scanner = new Scanner("a/b+d/c");
		//Scanner scanner = new Scanner("a+(b+d)/c");
		Scanner scanner = new Scanner("a-(b+c*d)/e");

		String inputStr = scanner.next();

		try {
			for (int i=0; i < inputStr.length(); i++) {

				//stack.print();

				char ch = inputStr.charAt(i);
				//System.out.println( "processing : " + ch);
				switch (ch) {
					case '*':
					case '/':
						while (!stack.empty() && 
								(Character) stack.peek() != '(' && 
								!stack.peek().equals('+') && 
								!stack.peek().equals('-') ) {
							System.out.println("inside * / ");
							postfixExp = postfixExp + stack.pop();
						}
						//System.out.println( "out of while * /  " );
						stack.push(ch);
						break;

					case '+':
					case '-':
						//System.out.println("stack is empty? " + stack.empty());
						while (!stack.empty() &&  
								(Character)stack.peek() != '(') {
							System.out.println("inside + - ");
							postfixExp = postfixExp + stack.pop();
						}
						//System.out.println("out of while + - ");
						stack.push(ch);
						break;
					case '(': 
						//System.out.println("inside ( ");
						stack.push( ch );
						break;
					case ')':
						//System.out.println("inside )" );
						while (!stack.peek().equals('('))
							postfixExp = postfixExp + stack.pop();
						stack.pop();
						break;
					default:  // operand
						//System.out.println("operand ");
						postfixExp = postfixExp + ch;
						break;
				}
			} // for loop
			while (!stack.empty())
				postfixExp = postfixExp + stack.pop();

		} catch (NoSuchElementException e) {
			//System.out.println("output of postfix so far: " + postfixExp);
			throw new NoSuchElementException (" bad input ");
		}

		System.out.println("output of postfix: " + postfixExp);
	}
}
