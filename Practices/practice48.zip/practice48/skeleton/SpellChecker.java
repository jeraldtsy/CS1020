// This program performs spell checking based on a spell-checker dictionary.

import java.util.*;

public class SpellChecker {
	public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";

	public static void main(String[] args) { 
		Scanner sc = new Scanner(System.in);



	}
}
