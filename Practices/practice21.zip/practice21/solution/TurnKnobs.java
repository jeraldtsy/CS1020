// This program reads in information of a number of knobs.
// For each knob, its current state, current position and
// target position. It then computes the state of each knob after
// the required number of stops, and the total stops of all knobs.

import java.util.*;

public class TurnKnobs {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<Knob> knobs = new ArrayList<Knob>();

		int num = sc.nextInt();
		sc.nextLine();
		for (int i=0;i<num;i++) {
			String line = sc.nextLine();
			String[] inputs = line.trim().split(" ");
			if (inputs.length==3)  // treat differently according to the state of knob
				knobs.add(new Knob(true, inputs[1], inputs[2]));
			else
				knobs.add(new Knob(false, inputs[0], inputs[1]));
		}

		int move = 0; 
		for (int i=0; i<knobs.size(); i++) {
			int thisMove = knobs.get(i).numOfMoves();        
			if (knobs.get(i).deviceIsOn(thisMove))              
				System.out.println("on");
			else
				System.out.println("off");
			move += thisMove;
		}
		System.out.println("Total stop(s) = " + move);
	}
}

