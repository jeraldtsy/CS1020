import java.io.*;

public class TestInputStream {

	public static void main(String[] args) throws IOException {
		InputStream in = new FileInputStream("msg_file");
		int value;

		while ((value = in.read()) != -1) {
			System.out.print((char)value);
		}
		System.out.println();
		in.close();
	}
}
