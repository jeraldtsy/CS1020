class BankAcct {

   private int acctNum;
   private double balance;

   public BankAcct() {   
      // By default, numeric attributes are initialised to 0
   }

   public BankAcct(int aNum, double bal) {
      acctNum = aNum;
      balance = bal;
   }

   public int getAcctNum() {   
      return acctNum;
   }

   public double getBalance() {   
      return balance;
   }

   public void deposit(double amount) {
      balance += amount;
   }
   
   public void withdraw(double amount) throws
                        NotEnoughFundException {   
      if (balance >= amount) {
         balance -= amount;
      } else {
         double needs = amount - balance;
         throw new NotEnoughFundException("Withdrawal Unsuccessful", needs);
      }
   }
}

