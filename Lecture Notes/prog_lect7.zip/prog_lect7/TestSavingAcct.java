public class TestSavingAcct {

	public static void main(String[] args) {

		SavingAcct sa1 = new SavingAcct(2, 1000.0, 0.03);

		sa1.print();
		sa1.withdraw(50.0);

		sa1.payInterest();
		sa1.print();
	}
} 

