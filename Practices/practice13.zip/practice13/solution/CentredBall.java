// CentredBall class:
//   Class attribute: quantity - number of balls created
//   Instance attributes: colour, radius, centre
// Aaron Tan

import java.awt.*;

class CentredBall {

	/************** Data members **********************/
	private static int quantity = 0; 

	private String colour;
	private double radius;
	private Point  centre;

	/************** Constructors **********************/
	// Default constructor creates a yellow ball, 
	// radius 10.0, centred at (0, 0)

	public CentredBall() {
		this("yellow", 10.0, new Point());
	}

	public CentredBall(String colour, double radius, Point centre) {
		setColour(colour);
		setRadius(radius);
		setCentre(centre);
		quantity++;
	}

	public CentredBall(String colour, double radius, int xCoord, int yCoord) {
		setColour(colour);
		setRadius(radius);
		setCentre(new Point(xCoord, yCoord));
		quantity++;
	}

	/**************** Accessors ***********************/
	public static int getQuantity() {
		return quantity; 
	}

	public String getColour() {
		return this.colour;   // 'this' is optional here
	}

	public double getRadius() {
		return this.radius;   // 'this' is optional here
	}

	public Point getCentre() {
		return this.centre;   // 'this' is optional here
	}

	/**************** Mutators ************************/
	public void setColour(String colour) {
		this.colour = colour;  // 'this' is required here
	}

	public void setRadius(double radius) {
		this.radius = radius;  // 'this' is required here
	}

	public void setCentre(Point centre) {
		this.centre = centre;  // 'this' is required here
	}

	/***************** Overriding methods ******************/
	// Overriding toString() method
	public String toString() {
		return "[colour=" + getColour() + ", radius=" + getRadius() 
		       + ", centre=(" + getCentre().x + "," + getCentre().y + ")]";
	}

	// Overriding equals() method
	public boolean equals(Object obj) {
		if (obj instanceof CentredBall) {
			CentredBall ball = (CentredBall) obj;
			return this.getColour().equals(ball.getColour()) &&
				this.getRadius() == ball.getRadius() &&
				this.getCentre().equals(ball.getCentre());
		}
		else
			return false;
	}
}

