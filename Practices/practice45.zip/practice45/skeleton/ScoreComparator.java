import java.util.*;

class ScoreComparator implements Comparator<Reading> {

	public int compare(Reading r1, Reading r2) {
		// fill in the code

	}

	public boolean equals(Object obj) {
		return this == obj;
	}
}

