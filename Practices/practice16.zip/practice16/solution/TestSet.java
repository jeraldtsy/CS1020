// This program reads two sets of integers A and B, and determines
// if A is a subset of B, and if A is the same as B.

import java.util.Scanner;
import java.util.ArrayList;

public class TestSet {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> list;

		System.out.print("Enter number of elements in set A: ");
		int setAsize = sc.nextInt();
		list = readSet(sc, "set A", setAsize);
		Set setA = new Set(list);

		System.out.print("Enter number of elements in set B: ");
		int setBsize = sc.nextInt();
		list = readSet(sc, "set B", setBsize);
		Set setB = new Set(list);

		System.out.println("Set A: " + setA); // for checking
		System.out.println("Set B: " + setB); // for checking

		if (setA.isSubset(setB)) {
			System.out.println("Set A is a subset of set B.");
		}
		else {
			System.out.println("Set A is not a subset of set B.");
		}

		if (setA.isSubset(setB) && setB.isSubset(setA)) {
			System.out.println("Set A is equal to set B.");
		}
		else {
			System.out.println("Set A is not equal to set B.");
		}
	}

	public static ArrayList<Integer> readSet(Scanner sc, String header, int size) {
		ArrayList<Integer> list = new ArrayList<Integer>(size);

		System.out.print("Enter elements for " + header + ": ");
		for (int i = 0; i < size; i++) {
			list.add(sc.nextInt());
		}
		return list;
	}
} 

