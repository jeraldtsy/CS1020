// This program reads a string, removes all its heading and
// trailing spaces, and replaces every block of consecutive
// spaces with a single space.
import java.util.*;

public class PrettyPrinter {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a line below:");
		String line = sc.nextLine();

		line = line.trim();
		String newLine = ""; // empty string
		int spacePos = line.indexOf(' '); // where is the first space in line?
		while (spacePos > -1) {
			newLine += line.substring(0, spacePos+1); 
			line = line.substring(spacePos+1);
			line = line.trim();
			spacePos = line.indexOf(' ');
		}
		newLine += line;

		System.out.println("Pretty-printed line:");
		System.out.println("|" + newLine + "|");
	}
}

