// CentredBall class:
//   Class attribute: quantity - number of balls created
//   Instance attributes: colour, radius, centre
import java.awt.*;

class CentredBall {

	/************** Data members **********************/
	private static int quantity = 0; 

	private String colour;
	private double radius;
	private Point  centre;

	/************** Constructors **********************/


	/**************** Accessors ***********************/


	/**************** Mutators ************************/


	/***************** Overriding methods ******************/
	// Overriding toString() method
	public String toString() {



	}

	// Overriding equals() method
	public boolean equals(Object obj) {




	}
}

