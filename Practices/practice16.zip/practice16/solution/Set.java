// Define the Set class

import java.util.ArrayList;

class Set {
	private ArrayList<Integer> members;

	// Constructors
	public Set() {
	}

	public Set(ArrayList<Integer> list) {
		members = list;
	}

	public String toString() {
		return members.toString();
	}

	// Return true if 'this' is a subset of 'set', 
	// otherwise return false.
	public boolean isSubset(Set set) {

		if (this.members.size() > set.members.size())
			return false;

		for (Integer element: this.members) {
			if (!set.members.contains(element))
				return false;
		}
		return true;
	}
}

