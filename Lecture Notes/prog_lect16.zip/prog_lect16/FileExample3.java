import java.util.*;
import java.io.*;

public class FileExample3 {

	public static void main(String[] args) 
		                     throws FileNotFoundException {
		
		File f = new File("example");
		if (!f.exists()) {
			System.out.println("File 'example' does not exist!");
			System.exit(1);
		}
		Scanner infile = new Scanner(f);
		int sum = 0;
		while (infile.hasNextInt()) {
			sum += infile.nextInt();
		}

		System.out.println("Sum = " + sum);
	}
}
