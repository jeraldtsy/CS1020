import java.io.*;

public class TestOutputStream {

	public static void main(String[] args) throws IOException {
		String msg = new String("Hello world!");
		OutputStream out = new FileOutputStream("msg_file");

		byte[] bytes = msg.getBytes();

		out.write(bytes);
		out.write(bytes[1]);
		out.write(10);  // ASCII value of newline
		out.write(bytes, 3, 5);
		out.close();
	}
}
