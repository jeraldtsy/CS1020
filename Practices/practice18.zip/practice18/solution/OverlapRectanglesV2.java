// This program reads in 4 vertices representing the opposite vertices
// of 2 rectangles and computes the overlap area of the rectangles.
// This program uses the MyRect class.
// Author: Aaron Tan

import java.util.*;
import java.awt.*;

public class OverlapRectanglesV2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter 2 opposite vertices of 1st rectangle: ");
		Point rect1Vertex1 = new Point(sc.nextInt(), sc.nextInt());
		Point rect1Vertex2 = new Point(sc.nextInt(), sc.nextInt());
		MyRect rect1 = new MyRect(rect1Vertex1, rect1Vertex2);

		System.out.print("Enter 2 opposite vertices of 2nd rectangle: ");
		Point rect2Vertex1 = new Point(sc.nextInt(), sc.nextInt());
		Point rect2Vertex2 = new Point(sc.nextInt(), sc.nextInt());
		MyRect rect2 = new MyRect(rect2Vertex1, rect2Vertex2);

		arrangeVertices(rect1);
		arrangeVertices(rect2);

   		System.out.println("1st rectangle: " + rect1);
   		System.out.println("2nd rectangle: " + rect2);

		if (rect1.equals(rect2))
			System.out.println("They are identical.");
		else
			System.out.println("They are not identical.");

		System.out.println("Overlap area = " + overlapArea(rect1, rect2));
	}


	// To rearrange the 2 opposite vertices of rect
	// such that the first vertex v1 becomes the bottom-left vertex
	// and the second vertex v2 becomes the top-right vertex.
	public static void arrangeVertices(MyRect rect) {
		int lowerX = Math.min(rect.getVertex1().x, rect.getVertex2().x);
		int upperX = Math.max(rect.getVertex1().x, rect.getVertex2().x);
		int lowerY = Math.min(rect.getVertex1().y, rect.getVertex2().y);
		int upperY = Math.max(rect.getVertex1().y, rect.getVertex2().y);

		rect.getVertex1().setLocation(lowerX, lowerY);
		rect.getVertex2().setLocation(upperX, upperY);
	}

	// To compute the overlap area of rectangles rect1 and rect2
	public static int overlapArea(MyRect rect1, MyRect rect2) {
		// If the 2 rectangles overlap, the overlap area
		// is also a rectangle, let's call it ov. Let the 
		// bottom-left vertex of ov be at point (botLeftX, botLeftY)
		// and its top-right vertex be at point (topRightX, topRightY).

		int botLeftX = Math.max(rect1.getVertex1().x, rect2.getVertex1().x);
		int topRightX = Math.min(rect1.getVertex2().x, rect2.getVertex2().x);
		int botLeftY = Math.max(rect1.getVertex1().y, rect2.getVertex1().y);
		int topRightY = Math.min(rect1.getVertex2().y, rect2.getVertex2().y);

		// If the 2 rectangles do not overlap, then either (topRightX - botLeftX) 
		// or (topRightY - botLeftY) would be negative.
		return Math.max(topRightX - botLeftX, 0) *
		       Math.max(topRightY - botLeftY, 0);
	}

}

