// To test out the CentredBall class 
// Aaron Tan

import java.util.*;
import java.awt.*;

public class TestCentredBall {

	// This method reads ball's input data from user, creates
	// a ball object, and returns it to the caller.
	public static CentredBall readBall(Scanner sc) {

		System.out.print("Enter colour, radius and centre: ");
		String inputColour = sc.next();
		double inputRadius = sc.nextDouble();
		int inputX = sc.nextInt();
		int inputY = sc.nextInt();

		// Create a ball object using the alternative constructor
		return new CentredBall(inputColour, inputRadius, new Point(inputX, inputY));
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		// Read input and create 1st ball object
		System.out.println("1st ball");
		CentredBall b1 = readBall(scanner);
		CentredBall largest = b1;

		// Read input and create 2nd ball object
		System.out.println("2nd ball");
		CentredBall b2 = readBall(scanner);
		if (b2.getRadius() > largest.getRadius())
			largest = b2;

		// Read input and create 3rd ball object
		System.out.println("3rd ball");
		CentredBall b3 = readBall(scanner);
		if (b3.getRadius() > largest.getRadius())
			largest = b3;

		System.out.println();
		if (b1.equals(b2))
			System.out.println("1st and 2nd balls are the same.");
		else
			System.out.println("1st and 2nd balls are not the same.");

		System.out.println("The largest ball created is:");
		System.out.println(largest);
	}
}

