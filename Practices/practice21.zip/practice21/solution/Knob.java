import java.util.*;

class Knob {

	// Data attributes 
	boolean isOn;       // is the device on?
	String currPos;     // current position of knob
	String targetPos;   // target position of knob

	// Constructor
	public Knob(boolean state, String newCurrPos, String newTargetPos) {  
		isOn = state;
		currPos = newCurrPos;
		targetPos = newTargetPos;
	}

	//  Determine whether the device is on or off after num moves
	public boolean deviceIsOn(int num) {
		if (num%2==0)
			return isOn;
		else
			return !isOn;
	}

	// Compute the least number of moves to turn the knob
	public int numOfMoves() {
		String[] positions = {"left","up","right","down","left","up","right"}; 
		int move = 0;
		boolean toEnd = false;

		// Turn to the same position = one round (4 stops)
		if (currPos.compareTo(targetPos)==0) 
			return 4;

		// Search the combination array
		for (int i=0; i<positions.length; i++) { 
			if (toEnd)
				break;

			// find the current position 
			if (currPos.compareTo(positions[i])==0) { 
				// advance the pointer to at most 3 to find the target
				for (int j=i+1; j<=3+i; j++){ 
					move++;
					// find the target position, change the flag 
					// and stop the loop 
					if (targetPos.compareTo(positions[j])==0) { 
						toEnd = true;
						break;
					}
				}
			}
		}
		return move;
	}
}

