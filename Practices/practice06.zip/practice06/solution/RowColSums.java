// RowColSums.java
// To compute the row and column sums of a 2D array.
import java.util.*;

class RowColSums {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter number of rows and columns: ");
		int rows = sc.nextInt();
		int cols = sc.nextInt();
		int[][] array2D = new int[rows][cols];

		System.out.println("Enter values for 2D array:");
		for (int r=0; r<array2D.length; r++) {
			for (int c=0; c<array2D[r].length; c++) {
				array2D[r][c] = sc.nextInt();
			}
		}

		// print2DArray(array2D); // for checking purpose

		int[] rowSums = computeRowSums(array2D);
		System.out.print("Row sums: ");
		System.out.println(Arrays.toString(rowSums));

		int[] colSums = computeColSums(array2D);
		System.out.print("Column sums: ");
		System.out.println(Arrays.toString(colSums));
	}

	// Compute row sums of 2D array arr
	public static int[] computeRowSums(int[][] arr) {
		int[] sumArr = new int[arr.length];

		for (int r=0; r<arr.length; r++) {
			for (int c=0; c<arr[r].length; c++) {
				sumArr[r] += arr[r][c];
			}
		}
		return sumArr;
	}

	// Compute column sums of 2D array arr
	public static int[] computeColSums(int[][] arr) {
		int[] colArr = new int[arr[0].length];

		for (int c=0; c<arr[0].length; c++) {
			for (int r=0; r<arr.length; r++) {
				colArr[c] += arr[r][c];
			}
		}
		return colArr;
	}

	// Print a 2D array
	public static void print2DArray(int[][] arr) {
		for (int r=0; r<arr.length; r++) {
			for (int c=0; c<arr[r].length; c++) {
				System.out.print(arr[r][c] + " ");
			}
			System.out.println();
		}
	}
}

