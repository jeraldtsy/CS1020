// Compute total weight of a batch of washers
// Add import statement below
import ...

// What should be the name of the class?
public class ... {

	// Compute area of a circle 
	// Fill in the method circleArea() below
	... circleArea( ... ) {


	}

	public static void main(String[] args) {
		// Fill in the code for the main() method

	}
}

