import java.util.*;

class QueueLLE <E> extends TailedLinkedList <E> implements QueueADT <E> {

	public boolean offer(E o) { 
		// write your code below


	}
	public E peek() {
		// write your code below


	}

	public E poll() {
		// write your code below



	}
}
