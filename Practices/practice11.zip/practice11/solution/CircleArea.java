// This program reads the length of a side of a square and
// computes the area of the circle that encloses the square.
import java.util.*;

public class CircleArea {

	// Returns the area of a circle of radius r
	public static double circleArea(double r) {
		return Math.PI * r * r;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter side of square: ");
		double side = sc.nextDouble();
		double radius = side/Math.sqrt(2);

		System.out.printf("Area of circle = %.2f\n", circleArea(radius));
	}
}

