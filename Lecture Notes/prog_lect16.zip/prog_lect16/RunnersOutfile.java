import java.util.*;
import java.io.*;

public class RunnersOutfile {

	public static void main(String[] args) 
		                     throws FileNotFoundException {

		Scanner infile = new Scanner(new File("runners_data"));

		int count = 0;
		double totalDist = 0.0;
		while (infile.hasNextLine()) {
			String line = infile.nextLine();
			Scanner sc = new Scanner(line);
			sc.nextInt(); // read ID
			sc.next();    // read name
			while (sc.hasNextDouble()) {
				count++;
				totalDist += sc.nextDouble();
			}
		}

		PrintStream outfile = new PrintStream(new File("running_stat"));
		outfile.printf("Total distance = %.2f\n", totalDist);
		outfile.printf("Average distance per run = %.2f\n", totalDist/count);
		outfile.close();
	}
}
