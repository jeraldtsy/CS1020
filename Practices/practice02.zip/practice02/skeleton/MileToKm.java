// Converts distance in miles to kilometres.
// Add import statement below
import ...

public class MileToKm {
	// Add constant below.
	// Java naming convention:
	// Constant names should be in uppercase, with words 
	// separated by underscores.

	public static void main(String[] args) {
		// Fill in the code for the main() method

	}
}

